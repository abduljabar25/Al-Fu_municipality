(function($) {
    "use strict";
	$('#lightgallery').lightGallery();
	$('#video-gallery').lightGallery(); 
})(jQuery);